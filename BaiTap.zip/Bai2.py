list
vehicle = ["car", "bicycle", "bus", "ship"]


def PrintCharacter():
    print(vehicle[1])


PrintCharacter()


def CutCharacter():
    print(vehicle[3][1:3])


CutCharacter()
