# def numpat(n):
#     num = 65
#     for i in range(0, n):
#         num = 1
#         for j in range(0, i+1):
#             print(num end=" ")
#             num = num + 1
#         print("\r")
# n = 5
# numpat(n)
for i in range(1, 6):
    for b in range(i):
        print(i, end=" ")
    print("\n")
