'''s = input()
print(s.upper())'''
 
###
print(input().upper())