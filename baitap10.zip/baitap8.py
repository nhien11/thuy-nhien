n=int(input("Nhập số n: "))
s=0
for i in range(0,n):
    s+=1/(i+1)
print("Kết quả:",s)