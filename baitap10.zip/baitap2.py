res = int(input())
a =[]
for i in range(res):
    a.append(int(input()))
print(*a,sep="")