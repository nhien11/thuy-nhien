age = int(input())

print("This can hardly be true" if age <= 0
 else "About 1 human year" if age == 1
 else "About 2 human years" if age == 2
 else "Over 5 human years")